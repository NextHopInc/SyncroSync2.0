import secret_key as keys
import requests as req
import json
class SyncroAssetWatcher:
    __syncro_url = "https://nexthop.syncromsp.com/api/v1/"
    __api_key = ""
    def __init__(self) -> None:
        self.__api_key = keys.getSyncro_APIKey()


    def request_companies(self) -> dict:
        #print(self.__syncro_url+"/customers/?fields=id,business_name,api_key="+self.__api_key)
        companies = req.get(url=self.__syncro_url+"/customers/?api_key="+self.__api_key)
        clean_data = {}
        total_entries = companies.json()['meta']['total_entries']
        # for i in companies.json().get("customers"):
        #     #clean_data.update({ count: {"id" :i.get("id") , "business_name" : i.get("business_name")}})
        #     self.__get_assets(i.get("id"), i.get("business_name"))
        return companies.json() , total_entries
            
    #Gets the company assets based off of the asset id
    def get_assets(self,id : int, name : str = None)->dict:
        # print(id)
        assets = req.get(url="https://nexthop.syncromsp.com/api/v1/customer_assets?api_key=Tae352eaf5afaf91df-dbbb9f96cca83f8d88317d8446688328&customer_id="+id)
        
        return assets.json()

    def get_specified_asset():
        pass
# sa = SyncroAssetWatcher()
# sa.request_companies()



