#!/usr/bin/env python
from SyncroAssetWatcher import SyncroAssetWatcher as saw
from ConnectWiseComparator import CWcomparator as cac
import time

def startup():
    sy = saw()
    companies , total = sy.request_companies()
    counter = 0
    for i in companies.get("customers"):
        syncro_assets = sy.get_assets(str(i.get("id")))
        cw = cac(syncro_assets, i.get("business_name"))
        status = cw.syncro_compare_connectwise()
        if(status == "COMPANY NOT FOUND"):
            print(status)
            time.sleep(5)
        print(f"Total Progress ==>> {counter} / {total} Percentage finished ==>> {counter/total}")
        time.sleep(2)
        counter += 1
    print("Finished Running Everything Complete")
    print("____________________________________")




if __name__ == "__main__":
    startup()

