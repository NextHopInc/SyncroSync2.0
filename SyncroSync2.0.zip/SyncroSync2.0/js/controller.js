$.ajax({
    url: 'index.html',
    type: 'GET',
    success: function(response) {
        console.log(response);
    },
    error: function(error) {
        console.error("Error running script:", error);
    }
});


console.log("Here in server side");
const express = require('express');
const { spawn } = require('child_process');
const app = express();

app.get('/run-script', (req, res) => {
    const pythonProcess = spawn('python', ["SyncroSync.py"]);
    pythonProcess.stdout.on('data', (data) => {
        console.log(`stdout: ${data}`);
        res.send(`Output: ${data}`);
    });
    pythonProcess.stderr.on('data', (data) => {
        console.error(`stderr: ${data}`);
        res.status(500).send(`Error: ${data}`);
    });
});

app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});