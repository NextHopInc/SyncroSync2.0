class CWExceptionHandler:


    def __init__(self, _error) -> None:
        self.error = _error

    
    def key_error_handler(self,syncro_asset : dict = {} ,cw_asset :dict = {} ) -> dict:
        print(f"IN EXCEPTION HANDLER ==>> {cw_asset} \n ERROR ==>> {self.error}")
        match(self.error):
            case 'site':
                cw_asset.update({'site' : {'id' : 737 , 'name' : 'Abbotsford Head Office'}})
            case 'manufacturer':
                print("MANUFACUTERE")
                cw_asset.update({'manufacturer' : {'id' : 3,'name' : 'Apple'}})
            case 'contact':
                print('contact')
            case _:
                exit()

        return cw_asset
    
    def contact_handler():
        pass    


            

