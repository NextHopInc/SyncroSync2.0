import secret_key as keys 
import requests as req
from datetime import datetime
import time
import os.path
from deepdiff import DeepDiff
import json

from CWExceptionHandler import CWExceptionHandler as cwe

#This is the class that compares the two assets. ==>> One from Syncromsp and another from Connectwise. 
#This class utilizes multiple classes that are located in this file (DataMiner, CWPost, CWPatch )
class CWcomparator():
    url = ""
    cwHeaders = ""
    code_base = ""
    cw_assets = []
    def __init__(self, s_assets , s_company) -> None:
        self.sy_assets = s_assets
        self.company = s_company
        self.cwHeaders = {"Authorization" : "Basic " + keys.generateToken(), "clientID":"3040b6af-ac90-42e6-932d-9178fc76f128"  ,\
                            "Content-Type":"application/json; charset=utf-8"\
                            , "Accept" : "application/vnd.connectwise.com+json; version=2022.1"}
        
        self.code_base = req.get(url = "https://na.myconnectwise.net/login/companyinfo/nexthop" , headers=self.cwHeaders ).json().get("Codebase")
        self.url = "https://api-na.myconnectwise.net/"+self.code_base+"//apis/3.0/"
        #get the assets from connectwise that have a similar name to the syncro company name 
        self.cw_assets = self.__filterAssets()
    
    #We get the assets for the company that was given from Syncromsp

    def __get_cw_assets(self) -> dict:
        jk = req.get(url=f"{self.url}company/configurations?conditions=company/name like '{self.company}'", headers=self.cwHeaders)
        print(f"THis is legnth of jk {len(jk.json())}")
        #Case if malformed request aka status code is anything besides 200
        if(jk.status_code != 200):
            if("'" in self.company):
                self.company = self.company.replace("'","%92")
                jk = req.get(url=f"{self.url}company/configurations?conditions=company/name like '{self.company}'", headers=self.cwHeaders)
        #Case status == 200, but nothing is found in connectwise 
        #Potential cause --> Company name spelled wrong or identifier used instead of company name. 
        elif(len(jk.json())==0):
            print("IN NEW EXCEPTION CASE")
            jk = req.get(url=f"{self.url}company/configurations?conditions=company/identifier like '{self.company}'", headers=self.cwHeaders)
        print(f"This is the url of get cw assets ==> {jk.url}")
        print(f"This is the status code ==>> {jk.status_code}")
        return jk.json()
    
    #Filter out all assets that are not a laptop, server or desktop
    def __filterAssets(self):
        try:
            data = self.__get_cw_assets()
            clData = self.cw_assets
            print(f"type of data from filter assets{type(data)} size of {len(data)}")
            if(type(data) == dict or type(data) == list):
                for i in data:
                    x = i.get("type").get("id")
                    #id of laptop, server or desktop
                    if(x == 69 or x == 8 or x == 30):
                        clData.append(i)
                    # print(clData)
        except AttributeError:
            print("Nothing found")
            print(f"Attribute Error here is dump {data}")
            return [] 
        return clData
    
    def syncro_compare_connectwise(self):
        popped_asset = {}
        for i in self.sy_assets.get("assets"):
            found = False
            j = 0
            while len(self.cw_assets) > 0 and j<len(self.cw_assets):
                try:
                    #this needs to be re written since we cannot have it based off names. Need a UID This is for the matching of the ids i.get("name").lower() == self.cw_assets[j].get("name").lower()
                    #
                    print(f'BEFORE VALUE CHECKER ==>> {self.cw_assets[j].get("customFields")}')
                    syncro_custom_id = 0
                    #Searching for custom field that contains the data we want
                    for x in range(len(self.cw_assets[j].get("customFields"))):
                        if(self.cw_assets[j].get("customFields")[x].get("caption")=="syncro assest id"):
                            syncro_custom_id = x
                            break
                    if("value" in self.cw_assets[j].get("customFields")[syncro_custom_id]):
                        print(f' what is currently trying to be matched ==>> {i.get("id")} and {self.cw_assets[j].get("customFields")[syncro_custom_id].get("value")}"')
                        if(int(i.get("id")) == int(self.cw_assets[j].get("customFields")[syncro_custom_id].get("value"))):
                            #If we find the asset remove it from the list. Any asset that is left we will mark as
                            #inactive in connectwise 
                            popped_asset = self.cw_assets.pop(j)
                            found = True
                            break
                        else:
                            print(f"Here are the assets we are looking for {i.get('name')} and {self.cw_assets[j].get('name')}")
                    else:
                        #If there is no asset id transfered from syncro to connectwise then we will remove it from list and add it to a file to be further inspected 
                        print("There is no id in connectwise configuration!")
                        print("Doesn't have counter part in syncro")
                        with open("notfound.txt" , "a") as file:
                            file.write(f"Connectwise asset with no counter part in Syncro ==>> {self.cw_assets[j].get('name')} Timestamp ==>> {datetime.now()}\n")
                            file.close()
                        self.cw_assets.pop(j)
                    
                    j+=1
                except Exception as e:
                    # print(i)
                    print(f"Exception has occured ==>> {e}")
                    j+=1
                    exit()
            print(f"THIS IS FOUND!!!! ==>> {found}")
            if(found):
                try:
                    print(f"Popped asset in found size ==>> {len(popped_asset)}")
                    differences = self.__find_differences(i,popped_asset)
                    self.push_patch(differences=differences,id=popped_asset['id'])
                    found = False
                except Exception as e:
                    print(f"ERROR ===== > {e}")
                    print(f"Index j == {j} length of list == {len(self.cw_assets)}")
                    exit()
                
            else:
                #One final check to see if we can find it by name!
                results = self.__request_by_name(i.get("name"))
                if(results != 404):
                    # print("THIS IS THE TYPE OF THE CW_ASSET ==>> ",type(popped_asset) , "  and size ==>> " , len(popped_asset))
                    differences = self.__find_differences(i,results)
                    self.push_patch(differences=differences,id=results['id'])
                #Now we can most likely declare it doesn't exist so we should create a new configuration in connectwise 
                else:
                    companyName, companyId , identity = self.__getCompany()
                    # if(companyName == None ):
                    #     return "COMPANY NOT FOUND"
                    contactName , contactId = self.__getContact(companyId)
                    siteName , siteId = self.__getSite(companyId)
                    manufacturer_name , manufacturer_id = self.__getManufacturer(i)
                    
                    jsBuild = dataMiner(syAsset=i,found=False,active=True,company=companyName,companyId=companyId,contact=contactName,contactId=contactId,site=siteName,siteId=siteId,manufacturer=manufacturer_name,manufacturerId=manufacturer_id , companyIdentifyer=identity , syncro_id=i.get("id"))
                    post = CWPost(jsBuild.json,self.url,self.cwHeaders)
                    print(f"site name {siteName} site id {siteId}")
                    print(f"COmpany name = {companyName} companyId {companyId}")
                    print(f"Name of contact {contactName} id of contact {contactId}")
                    print(jsBuild.json)
                    #uncomment this to post 
                    #results = post.post()
                    #print(f"Results of post attempt ==>> {results}")
                    
                    pass

        #means that the we have some machines that are not in use anymore, we need to mark them as
        #inactive
        if(len(self.cw_assets) > 0):
            for i in self.cw_assets:
                #dm = dataMiner(i,False)
                pass
    
    def push_patch(self,differences : DeepDiff, id):
        print(differences.to_dict())
        js = differences.to_dict()
        if("values_changed" in js.keys()):
            for j in js['values_changed']:
                #print("This is what it is ==>> " ,type(j) , "  VALUE OF J == " , j , "  VALUE STORED HERE  ",js['values_changed'][j]['new_value'] , "  AFFECTED  root keys == " , differences.affected_root_keys, "  TYPE == " , type(differences.affected_root_keys))
                path = j.strip("root")
                path = path.strip("'][")
                count = 0
                while("]" in path or "'" in path or "[" in path):
                    path = path.replace("'" , "")
                    path = path.replace("[" , "")
                    path = path.replace("]" , "/")
                    if count > 4:
                        break
                    else:
                        count+=1
                patch = CWPatch(id=id, values=differences['values_changed'][j]['new_value']  ,url=self.url,headers=self.cwHeaders , path=path)
                patch.patch()
        else:
            print("Nothing to change")



    def __find_differences(self, syncro_asset, cw_asset):
        print("FINDING DIFFERENCES")
        f_syncro_asset , f_cw_asset = self.__formatter(syncro_asset , cw_asset)
        differences = DeepDiff(f_cw_asset,f_syncro_asset,ignore_order=True)
        print(f"Here are the differences ==>> {differences.affected_root_keys} type of differences ==>> {type(differences.to_json())}")
        return differences

    def __formatter(self,syncro_asset : dict , cw_asset : dict):
        companyName, companyId , identity = self.__getCompany()
        contactName , contactId = self.__getContact(companyId)
        siteName , siteId = self.__getSite(companyId)
        manufacturer_name , manufacturer_id = self.__getManufacturer(syncro_asset)
        no_error = True
        f_cw_asset =None
        f_syncro_asset = None
        
        f_syncro_asset = dataMiner(syAsset=syncro_asset,cwAsset=cw_asset,found=False,active=True,company=companyName,companyId=companyId,companyIdentifyer=identity,contact=contactName,contactId=contactId,site=siteName,siteId=siteId,manufacturer=manufacturer_name,manufacturerId=manufacturer_id,syncro_id=syncro_asset.get("id"))
        print(cw_asset)
        print(f"Size of cw_asset after dataminer call ==>> {len(cw_asset)}")
        #all(key in cw_asset for key in keys)
        try:
            f_cw_asset = dataMiner(syAsset=syncro_asset,found=True,cwAsset=cw_asset,active=True,company=cw_asset['company']["name"],companyId=cw_asset['company']["id"],companyIdentifyer=cw_asset['company']["identifier"], contact=cw_asset['contact']['name'],contactId=cw_asset['contact']['id'], site=cw_asset['site']['name'],siteId=cw_asset['site']['id'],manufacturer=cw_asset['manufacturer']['name'],manufacturerId=cw_asset['manufacturer']['id'],syncro_id=syncro_asset['id'])
                #f_cw_asset = dataMiner(syAsset=syncro_asset,found=True,cwAsset=cw_asset,active=True,company=cw_asset['company']["name"],companyId=cw_asset['company']["id"],companyIdentifyer=cw_asset['company']["identifier"], contact=cw_asset['contact']['name'],contactId=cw_asset['contact']['id'], site=cw_asset['site']['name'],siteId=cw_asset['site']['id'],manufacturer="Apple" , manufacturerId=3,syncro_id=syncro_asset['id'])
        except Exception as e:
            print(f"THIS IS HTE EXCEPTION ==>> {e} this is type ==>> {type(e)} as string ==>> {str(e.args[0])}")
            new_key_error = cwe(str(e.args[0]))
            
            cw_asset = new_key_error.key_error_handler(syncro_asset,cw_asset)
            if(str(e.args[0])=='name' or str(e.args[0])=='contact'):
                res = req.get(f"{self.url}company/contacts?conditions=company/id={cw_asset['company']['id']}&fields=firstname,lastname,id" , headers=self.cwHeaders)
                print(res.json())
                if('lastName' in res.json()[0].keys()):
                    cw_asset.update({'contact' :{
                        'name' : res.json()[0]['firstName'] + res.json()[0]['lastName'],
                        'id' : res.json()[0]['id']
                    } })
                else:
                    cw_asset.update({'contact' :{
                        'name' : res.json()[0]['firstName'],
                        'id' : res.json()[0]['id']
                    } })
            e_f_syncro_asset, e_f_cw_asset = self.__formatter(syncro_asset=syncro_asset , cw_asset=cw_asset)
            no_error = False
        
        if(no_error):
            return f_syncro_asset.json , f_cw_asset.json
        else:
            return e_f_syncro_asset,e_f_cw_asset

    #If the original search of finding data within the company request fails, we search by name and return results 
    def __request_by_name(self,syncro_name):
        print("Made it to request by name")
        results = req.get(f"{self.url}company/configurations?conditions=name like '{syncro_name}' AND company/name like '{self.company}'" , headers=self.cwHeaders)
        if(results.status_code == 200 and len(results.json())>0):
            print(f"Here are the results == {results.json()}")
            return results.json()[0]
        else:
            print(f"Cant find it here are the results == {results.json()}")
            with open("notfound.txt" , "a") as file:
                file.write(f"{syncro_name}\n")
            return 404
    #This is a final search for the reamining assets in the self.cw_assets list. We are going to request those assets from syncro and see if they exist.
    #Reason for doing this, is some assets exist under a different company name in connectwise than they do in Syncro 
                
    def __getCompany(self):
        try:
            data = req.get(url=f"{self.url}company/companies?conditions=name like '%{self.company}%'&fields=name,id,identifier" , headers=self.cwHeaders)
            #print("COMPANY   " , data.json() , "URL " ,data.url)
            return data.json()[0].get("name") , data.json()[0].get("id") , data.json()[0].get("identifier")
        except:
            print(data.url)
            print(f"Error thrown getting company here is data {data.json()}")
            print("This is status code ==>> ",data.status_code)
            if(len(data.json())==0):
                if("'" in self.company):
                    cmpy = self.company.replace("'", "%92")
                    data = req.get(url=f"{self.url}company/companies?conditions=name like '%{cmpy}%'&fields=name,id,identifier" , headers=self.cwHeaders)
                    if(data.status_code == 200 and len(data.json())>0):
                        print(f"SUCCESS!!!! DATA FOUND ==>> {data.json()}")
                        return data.json()[0].get("name") , data.json()[0].get("id") , data.json()[0].get("identifier")
                    
            
            x = "St Ann Catholic Church"
            print("FINAL CLAUSE IM SO CONFUSED")
            data = req.get(url=f"{self.url}company/companies?conditions=identifier like '{x}'", headers=self.cwHeaders)
            print(f"This is the function data after call with identifier ==>> {data.url} and {data.json()}")
            if(data.status_code == 200 and len(data.json())>0):
                print(f"DATA FOUND IN FINAL CLAUSE ==>> {data.json()}")
                return data.json()[0].get("name") , data.json()[0].get("id") , data.json()[0].get("identifier")
            return None, None , None
    
    def __getContact(self, compId : int = 0):
        try:
            data = req.get(url=f"{self.url}company/contacts?conditions=company/id={compId}&fields=firstname,lastname,id" , headers=self.cwHeaders)
            print(data.url)
            #print(data.json())
            return data.json()[0].get("firstName") + " " + data.json()[0].get("lastName") , data.json()[0].get("id")
        except TypeError:
            print(f"Can only concatenate str not none type {data.json()[0].get('firstName') ,'  ', data.json()[0].get('lastName') , data.json()[0].get('id')}")
            return data.json()[0].get("firstName") , data.json()[0].get("id")
        except KeyError as e:
            print(f"THis is the error ==>> {e} this is the data ==>> {data.json()}")
            err = cwe('contact')
            d = err.key_error_handler()
            return d.get("firstname") + d.get('lastname') , d.get('id')
    
    def __getSite(self , compId):
        data = req.get(url=f"{self.url}company/companies/{compId}/sites?fields=id,name" , headers=self.cwHeaders)
        print(data.url)
        try:
            return data.json()[0].get("name") , data.json()[0].get("id")
        except:
            print(f"Error in getSite ==>> {data} and type {type(data)}")
            return data.json().get("name") , data.json().get("id")
        
    def __getManufacturer(self, i):
        try:
            data = req.get(url=f"{self.url}procurement/manufacturers?conditions=name like '{i.get('properties').get('kabuto_information').get('general').get('manufacturer')}'&fields=name,id" , headers=self.cwHeaders)
            print(data.url)
            #print(data.json())
            return data.json()[0].get("name") , data.json()[0].get("id")
        except:
            print(f"Data of get manufacurer == {data.json()}")
            return None , None



#Building Json file and parsing the data needed for building the json file 

class dataMiner():
    config_found = False
    def __init__(self , cwAsset : list = [], syAsset : list = [] , found : bool = False ,active : bool = False, company : str = "" ,companyIdentifyer : str = "", companyId : int = 0 , contact : str = "" , contactId : int = 0 , site : str = "" , siteId : int = 0 , manufacturer : str = "" , manufacturerId : int = 0 , syncro_id : int = 0) -> None:
        self.cw_asset = cwAsset
        self.sy_asset = syAsset
        self.config_found = found
        self.config_active = active
        self.company_name = company
        self.company_id = companyId
        self.contact_name = contact
        self.contact_id = contactId
        self.site_id = siteId
        self.site_name = site
        self.manufacturer = manufacturer
        self.manufacturer_id = manufacturerId
        self.company_identity = companyIdentifyer
        self.syncro_id = syncro_id
        self.json = self.jsonBuilder()


    
    def jsonBuilder(self):
        form_factor, form_id = self.__getFormFactor()
        print(f"Here is cw_asset in jsonBuilder ==>> {self.cw_asset}")
        
        # Ensure all attributes and method calls return serializable types
        installationDate = self.sy_asset.get("properties", {}).get("kabuto_information", {}).get("install_dates", {}).get("os_install") if not self.config_found else self.cw_asset.get('installationDate')
        ipAddress = self.__getIPaddress() if not self.config_found else self.cw_asset.get('ipAddress')
        macAddress = self.__getMACAddress() if not self.config_found else self.cw_asset.get('macAddress')
        defaultGateway = self.__getDeafaultGateway() if not self.config_found else self.cw_asset.get('defaultGateway')
        ram = self.__getRam() if not self.config_found else self.cw_asset.get('ram')
        osType = self.__getOS() if not self.config_found else self.cw_asset.get('osType')
        cpuSpeed = self.__getCPU() if not self.config_found else self.cw_asset.get('cpuSpeed')
        serialNumber = self.__getSerial() if not self.config_found else self.cw_asset.get('serialNumber')
        modelNumber = self.__getModel() if not self.config_found else self.cw_asset.get('modelNumber')
        lastLoginName = self.__getLastLogin() if not self.config_found else self.cw_asset.get('lastLoginName')

        jsonFile = {
            "id": 0,
            "name": self.sy_asset.get("name"),
            "type": {
                "id": form_id,
                "name": form_factor,
            },
            "status": {
                "id": 1,
                "name": "Active",
            },
            "company": {
                "id": self.company_id,
                "identifier": self.company_identity,
                "name": self.company_name,
            },
            "contact": {
                "id": self.contact_id,
                "name": self.contact_name,
            },
            "site": {
                "id": self.site_id,
                "name": self.site_name,
            },
            "manufacturer": {
                "id": self.manufacturer_id,
                "name": self.manufacturer,
            },
            "installationDate": installationDate,
            "billFlag": 1,
            "ipAddress": ipAddress,
            "macAddress": macAddress,
            "defaultGateway": defaultGateway,
            "ram": ram,
            "osType": osType,
            "cpuSpeed": cpuSpeed,
            "tagNumber": "zz",
            "serialNumber": serialNumber,
            "modelNumber": modelNumber,
            "lastLoginName": lastLoginName,
            "customFields": [
                {
                    "id": 1,
                    "caption": "syncro assest id",
                    "type": "Text",
                    "entryMethod": "EntryField",
                    "numberOfDecimals": 0,
                    "value": self.syncro_id
                }
            ]
        }
        
        return dict(jsonFile)
    

    #Private Data parsing functions 

    #Find what it is server,laptop or desktop
    def __getFormFactor(self):
        try: 
            factor = self.sy_asset.get("properties").get("form_factor")
            if(factor == ""): 
                return ""
            else: 
                if("Server" in factor or "server" in factor): 
                    return "Server" , 8
            if("Laptop" in factor or "laptop" in factor):
                return "Laptop" , 69
            if("Desktop" in factor or "desktop" in factor):
                return "Desktop", 30
        except: 
            print(f"Cannot find form factor")
            return "Desktop" , 30

    def __getIPaddress(self): 
        ip = ""
        try:
            for i in range(len(self.sy_asset.get("properties").get("kabuto_information").get("network_adapters"))):
                ip = self.sy_asset.get("properties").get("kabuto_information").get("network_adapters")[i].get("ipv4")
                if(ip!=""):
                    break
            return ip 
        except :
            return "169.000.0.000"

    def __getMACAddress(self):
        mac = "0:0:0:0:0:0"
        try:
            mac = self.sy_asset.get("properties").get("configuration").get("mac_address")
            return mac
        except : 
            return "0:0:0:0:0:0"

    def __getDeafaultGateway(self):
        gateway = ""
        try:
            for i in range(len(self.sy_asset.get("properties").get("kabuto_information").get("network_adapters"))):
                gateway = self.sy_asset.get("properties").get("kabuto_information").get("network_adapters")[i].get("gateway")
                if(gateway!=""):
                    return gateway
        except : 
            return "169.000.0. "
    
    def __getRam(self):
        try:
            ram = self.sy_asset.get("properties").get("kabuto_information").get("ram_gb")
            return ram 
        except : 
            return "Cant get RAM"
    
    def __getOS(self):
        try:
            osname = self.sy_asset.get("properties").get("kabuto_information").get("os").get("name")
            if(osname==""):
                return ""
            else:
                return osname
        except : 
            return ""
    
    def __getCPU(self):
        try: 
            cpu = self.sy_asset.get("properties").get("kabuto_information").get("cpu")[0].get("name")
            if(cpu==""):
                return ""
            else: 
                return cpu
        except : 
            return ""
    
    def __getSerial(self):
        try: 
            serial = self.sy_asset.get("properties").get("kabuto_information").get("general").get("serial_number")
            if(serial == ""): 
                return ""
            else: 
                return serial 
        except: 
            return ""
    
    def __getModel(self):
        try: 
            model = self.sy_asset.get("properties").get("model")
            if(model == ""): 
                return ""
            else: 
                return model
        except: 
            return""
    
    def __getLastLogin(self):
        try: 
            login = self.sy_asset.get("properties").get("kabuto_information").get("last_user")
            if(login == ""): 
                return ""
            else: 
                return login
        except: 
            return ""


#These are the classes that will send the final product to connectwise 

class CWPost():
    #fields that need to be filled in 

    def __init__(self, post_data , url , headers) -> None:
        self.post_data = post_data
        self.url = url
        self.headers = headers

    def post(self):
        print("Posting")
        print(self.post_data)
        results = req.post(url=f"{self.url}company/configurations",json=self.post_data , headers=self.headers)
        if(results.status_code != 201):
            if os.path.isfile("error.txt"):
                with open("error.txt" , "a")as file:
                    file.write(f"Error Posting ==>> {results.json()} Error Code ==>> {results.status_code} Timestamp ==>> {datetime.now()}\n")
                    file.close()
            else:
                with open("error.txt" , "w") as file:
                    file.write(f"Error Posting ==>> {results.json()} Error Code ==>> {results.status_code} Timestamp ==>> {datetime.now()}\n")
                    file.close()
        else:
            print("Posted!")
        return results.status_code

class CWPatch():
    def __init__(self, id , values, path , url , headers) -> None:
        self.id = id
        self.value = values
        self.path = path
        self.url = url
        self.headers = headers
    def patch(self):
        print("Patching")

        #print( path,identify , element , "ELEMENT")
        if(self.path == "company"):
            #x = [{"op" : "replace" , "path" : self.path , "value" : {identify : element}}]
            pass
        else: 
            x = [{"op" : "replace" , "path" : self.path , "value" : self.value}] 

        requests = req.patch(url=self.url+"company/configurations/"+str(self.id),json=x , headers=self.headers)
        #print(x)
        print(requests.url)
        print("Status= " ,requests.status_code,"\n")
        #print(requests.json())
        if(requests.status_code != 200): 
            print(requests.json())
            print(requests.status_code)
        
            with open("error.txt" , "w") as file:
                file.write(f"Error patching ==>> {requests.json()} Error Code ==>> {requests.status_code} Data we are trying to send ==>> {self.value} Timestamp ==>> {datetime.now()}\n")
                file.close()
            exit()
        else: 
            print(f"Status of patch request == {requests.status_code} url == {requests.url}")
            #time.sleep(5)
        





# cw = CWcomparator("" , "Cadex Electronics Inc.")
