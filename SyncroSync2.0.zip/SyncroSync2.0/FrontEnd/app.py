from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # This will enable CORS for all routes

@app.route('/run_python', methods=['POST'])
def run_python():
    data = request.get_json()
    input_value = data.get('input')
    output_value = input_value * 2
    return jsonify({'output': output_value})

if __name__ == '__main__':
    app.run(debug=True)