from deepdiff import DeepDiff

# data1 = {'id': 9491, 'name': '7GEN-LT03', 'type': {'id': 69, 'name': 'Laptop', '_info': {'type_href': 'https://api-na.myconnectwise.net/v4_6_release/apis/3.0//company/configurations/types/69'}}, 'status': {'id': 1, 'name': 'Active', '_info': {'status_href': 'https://api-na.myconnectwise.net/v4_6_release/apis/3.0//company/configurations/statuses/1'}}, 'company': {'id': 1055, 'identifier': '7 Generations Medical', 'name': '7 Generations Medical', '_info': {'company_href': 'https://api-na.myconnectwise.net/v4_6_release/apis/3.0//company/companies/1055'}}, 'contact': {'id': 3949, 'name': 'Ellen Whatley', '_info': {'contact_href': 'https://api-na.myconnectwise.net/v4_6_release/apis/3.0//company/contacts/3949'}}, 'site': {'id': 1223, 'name': 'Main', '_info': {'site_href': 'https://api-na.myconnectwise.net/v4_6_release/apis/3.0//company/companies/1055/sites/1223'}}, 'locationId': 2, 'location': {'id': 2, 'name': 'Abbotsford', '_info': {'location_href': 'https://api-na.myconnectwise.net/v4_6_release/apis/3.0//system/locations/2'}}, 'businessUnitId': 16, 'department': {'id': 16, 'identifier': 'Operations', 'name': 'Operations', '_info': {'department_href': 'https://api-na.myconnectwise.net/v4_6_release/apis/3.0//system/departments/16'}}, 'serialNumber': 'PF4YZ4G3', 'modelNumber': '21JT001PUS', 'tagNumber': 'zz', 'installationDate': '2024-07-06T06:46:44Z', 'macAddress': 'FC-5C-EE-E4-91-44', 'lastLoginName': '7GEN-LT03\\Harjot', 'billFlag': True, 'ipAddress': '169.254.73.89', 'defaultGateway': 'fe80::ee6c:9aff:fe98:1f6a%14', 'osType': 'Microsoft Windows 11 Pro', 'cpuSpeed': 'AMD Ryzen 5 7530U with Radeon Graphics         ', 'ram': '8', 'manufacturer': {'id': 12, 'name': 'Lenovo', '_info': {'manufacturer_href': 'https://api-na.myconnectwise.net/v4_6_release/apis/3.0//procurement/manufacturers/12'}}, 'activeFlag': True, 'mobileGuid': 'e7006a0b-c6af-4ffc-9bc3-5b3c91d8ae6d', 'companyLocationId': 2, 'showRemoteFlag': False, 'showAutomateFlag': False, 'needsRenewalFlag': False, '_info': {'lastUpdated': '2024-07-23T23:54:15Z', 'updatedBy': 'syncrosync', 'dateEntered': '2024-07-23T23:54:15Z', 'enteredBy': 'syncrosync'}, 'customFields': [{'id': 1, 'caption': 'syncro assest id', 'type': 'Text', 'entryMethod': 'EntryField', 'numberOfDecimals': 0, 'value': '9919340'}]}
# data2 = {'id': 9491, 'name': '7GEN-LT03', 'type': {'id': 67, 'name': 'Laptop', '_info': {'type_href': 'https://api-na.myconnectwise.net/v4_6_release/apis/3.0//company/configurations/types/69'}}, 'status': {'id': 1, 'name': 'Active', '_info': {'status_href': 'https://api-na.myconnectwise.net/v4_6_release/apis/3.0//company/configurations/statuses/1'}}, 'company': {'id': 1055, 'identifier': '7 Generations Medical', 'name': '7 Generations Medical', '_info': {'company_href': 'https://api-na.myconnectwise.net/v4_6_release/apis/3.0//company/companies/1055'}}, 'contact': {'id': 3949, 'name': 'Ellen Whatley', '_info': {'contact_href': 'https://api-na.myconnectwise.net/v4_6_release/apis/3.0//company/contacts/3949'}}, 'site': {'id': 1223, 'name': 'Main', '_info': {'site_href': 'https://api-na.myconnectwise.net/v4_6_release/apis/3.0//company/companies/1055/sites/1223'}}, 'locationId': 2, 'location': {'id': 2, 'name': 'Abbotsford', '_info': {'location_href': 'https://api-na.myconnectwise.net/v4_6_release/apis/3.0//system/locations/2'}}, 'businessUnitId': 16, 'department': {'id': 16, 'identifier': 'Operations', 'name': 'Operations', '_info': {'department_href': 'https://api-na.myconnectwise.net/v4_6_release/apis/3.0//system/departments/16'}}, 'serialNumber': 'PF4YZ4G3', 'modelNumber': '21JT001PUS', 'tagNumber': 'zz', 'installationDate': '2024-07-06T06:46:44Z', 'macAddress': 'FC-5C-EE-E4-91-44', 'lastLoginName': '7GEN-LT03\\Harjot', 'billFlag': True, 'ipAddress': '169.254.73.89', 'defaultGateway': 'fe80::ee6c:9aff:fe98:1f6a%13', 'osType': 'Microsoft Windows 11 Pro', 'cpuSpeed': 'AMD Ryzen 5 7530U with Radeon Graphics         ', 'ram': '8', 'manufacturer': {'id': 12, 'name': 'Lenovo', '_info': {'manufacturer_href': 'https://api-na.myconnectwise.net/v4_6_release/apis/3.0//procurement/manufacturers/12'}}, 'activeFlag': True, 'mobileGuid': 'e7006a0b-c6af-4ffc-9bc3-5b3c91d8ae6d', 'companyLocationId': 2, 'showRemoteFlag': False, 'showAutomateFlag': False, 'needsRenewalFlag': False, '_info': {'lastUpdated': '2024-07-23T23:54:15Z', 'updatedBy': 'syncrosync', 'dateEntered': '2024-07-23T23:54:15Z', 'enteredBy': 'syncrosync'}, 'customFields': [{'id': 1, 'caption': 'syncro assest id', 'type': 'Text', 'entryMethod': 'EntryField', 'numberOfDecimals': 0, 'value': '9919340'}]}

# result = DeepDiff(data1,data2)

# print(result)

# print(result.affected_paths)
# print(result.affected_root_keys)
# print(result.to_dict())

# di = result.to_dict()

# for i in di['values_changed']:
#     print(i)
#     path = i.strip("root")
#     path = path.strip("'][")
#     count = 0
#     while("]" in path or "'" in path or "[" in path):
#         path = path.replace("'" , "")
#         path = path.replace("[" , "")
#         path = path.replace("]" , "/")
#         if count > 4:
#             break
#         else:
#             count+=1
#     print(path)

data = [{'id': 1, 'caption': 'syncro assest id', 'type': 'Text', 'entryMethod': 'EntryField', 'numberOfDecimals': 0, 'value': '9783459', 'connectWiseId': '217424eb-092d-ef11-828c-98bb205dba74'}]

if('value' in data[0]):
    print("YES")
    print(data[0].get("value"))

