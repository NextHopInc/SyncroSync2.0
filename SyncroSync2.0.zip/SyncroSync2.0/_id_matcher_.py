from SyncroAssetWatcher import SyncroAssetWatcher as saw 
from ConnectWiseComparator import CWcomparator as cac

if __name__  == '__main__':
    sy = saw()   
    companies = sy.request_companies()

    for i in companies.get("customers"):
        # print(f"Current Customers  == {companies.get('customers')}")
        sy_assets = sy.get_assets(str(i.get("id")))
        cw = cac(sy_assets , i.get("business_name"))
        cw.syncro_compare_connectwise()
    print("FINISHED RUNNING EVERYTHING COMPLETE")
    print("_____________________________________")